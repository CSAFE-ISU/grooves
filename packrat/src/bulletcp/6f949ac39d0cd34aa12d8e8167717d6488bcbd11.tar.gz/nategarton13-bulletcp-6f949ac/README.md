# bulletcp
Repo for bullet groove changepoint algorithm.
