library(testthat)
library(bulletxtrctr)

test_check("bulletxtrctr")
