## 3. Resubmission
* Uwe, thanks so much for your help - you are right, we hadn't tested the function well, and not at all on Windows. I very much appreciate all of your helpful comments. 
* platform dependencies are removed from write_x3p
* added example to write_x3p that creates a temporary x3p file

## 2. Resubmission
* I have added additional small examples to every function (except for write_x3p)

## 1. Resubmission
this is a resubmission, I have 

* changed LICENSE file to CRAN template
* removed VignetteBuilder tag from DESCRIPTION


## Test environments
* local OS X install, R 3.4.4
* ubuntu 12.04 (on travis-ci), R 3.4.4
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note (maintainer email)

* This is a new release.

## Reverse dependencies

This is a new release, so there are no reverse dependencies.

