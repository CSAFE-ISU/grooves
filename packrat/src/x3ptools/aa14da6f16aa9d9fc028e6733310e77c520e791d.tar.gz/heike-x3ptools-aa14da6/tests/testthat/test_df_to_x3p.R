context("df_to_x3p")

# Test missing values messages
dftest2 <- dftest[sample(1:42, size = 38), c(1, 2, 4)]


test_that("df_to_x3p works as expected", {
  suppressWarnings(
    expect_error(df_to_x3p(dftest[,1:3]),
               "!is.null.dframe\\$value. is not TRUE"))

  expect_silent(tmp <- df_to_x3p(dftest[,c(1, 2, 4)]))
  expect_equivalent(tmp$surface.matrix,
                    matrix(dplyr::arrange(dftest, desc(y))$value,
                           byrow = F, nrow = 6))
  expect_equivalent(tmp$header.info, list(sizeX = 6, sizeY = 7, incrementX = 1, incrementY = 1))
  
  expect_message(
    x3ptest2 <- df_to_x3p(dftest2),
    "dframe has missing values ... they will be expanded")
})

test_that("x3p_to_df works as expected", {
  expect_silent(tmp <- x3p_to_df(x3ptest))
  expect_equivalent(tmp %>% 
                      dplyr::mutate(x = x + 1, y = y + 1) %>% 
                      dplyr::arrange(y, x), 
                    dftest[,c(1, 2, 4)])
})
