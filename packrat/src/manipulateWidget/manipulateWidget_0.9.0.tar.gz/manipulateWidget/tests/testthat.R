library(testthat)
library(manipulateWidget)

test_check("manipulateWidget")
